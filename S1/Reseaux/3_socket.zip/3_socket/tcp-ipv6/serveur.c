#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>     /* pour read(2)/write(2) */

#include <netdb.h>      
#include <string.h>     /* pour memset */

#include <ctype.h>      /* pour toupper */

#include <arpa/inet.h>  /* pour inet_ntop */

#define REQUEST_MAX 1024  /* taille MAX en réception */

void usage() {
  fprintf(stderr,"usage : serveur port\n"); 
  exit(1);
}

int main(int argc, char **argv) {
  int s, sock, ret;
  socklen_t n;
  int broadcastPermission;
  unsigned int sendStringLen;   
  char *broadcastIP,b1[100]; 
  unsigned short broadcastPort; 
  char *sendString; 
  struct sockaddr_in broadcastAddr,client,server; 

  //struct addrinfo hints, *result;
  struct sockaddr_storage src_addr;
  //socklen_t len_src_addr;

  char request[REQUEST_MAX];

  /* Vérification des arguments */
  /*if(argc!=2) {
    fprintf(stderr,"Erreur : Nb args !\n");
    usage();
  }*/

 
  if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0){
	perror("sock"); exit(1);
  }
   s=socket(AF_INET,SOCK_DGRAM,0);
   server.sin_family=AF_INET;
   server.sin_port=2000;
   server.sin_addr.s_addr=inet_addr("127.0.0.1");

  
  /* Attachement de la socket */
  if (bind(s,(struct sockaddr *)&server,sizeof(server)) == -1) {
    perror("bind"); exit(1);
  }
system("echo a");
  /* Set socket to allow broadcast */
  broadcastPermission = 1;
  if (setsockopt(s, SOL_SOCKET, SO_BROADCAST, (void *) &broadcastPermission, sizeof(broadcastPermission)) < 0)
        system("echo erreur");//perror("setsockopt() failed");  exit(1);

  memset(&broadcastAddr, 0, sizeof(broadcastAddr));/* Zero out structure */
system("echo a");
  broadcastAddr.sin_family = AF_INET;/* Internet address family */
  broadcastAddr.sin_addr.s_addr = inet_addr(broadcastIP);/* Broadcast IP address */
  broadcastAddr.sin_port = htons(broadcastPort);/* Broadcast port */
system("echo a");
  /* définition de la taille de la file d'attente */

int conn;
  while(1) { /* boucle du serveur */

    /* Attente d'une connexion */
    unsigned int size = sizeof (client);
    n=sizeof(client);
    puts("En attente de connexion...");
    recvfrom(s,b1,sizeof(b1),0,(struct sockaddr *) &client,&n);
    //len_src_addr=sizeof src_addr;
    if((conn=accept(s, (struct sockaddr *)&client, 
      &size))==-1) {
      perror("accept"); exit(1);
    }

    puts("Connexion acceptée !");

    /* boucle de traitement du client */

    while((ret=read(sock, request, REQUEST_MAX))>0) {

       scanf("%s",sendString);
       sendStringLen = strlen(sendString);  /* Find length of sendString */
sendto(sock, sendString, sendStringLen, 0, (struct sockaddr *)&broadcastAddr, sizeof(broadcastAddr));
sleep(3);
    }
       

    /* fin de la boucle de traitement du client */

    if(close(sock)==-1) {
      perror("close"); exit(1);
    }

    fprintf(stderr, "Fin de connexion !\n");
    if(ret==-1) {
      perror("read");
    }

  } /* fin boucle principale du serveur */

  return 0;
}

