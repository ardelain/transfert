package model;

import utils.*;
import java.util.Date;

public class Task {
  private String idTask;
  private String title;
  private Date creationDate;
  private Date lastModifDate;
  private String content;

  public String getIdTask(){
    return this.idTask;
  }
  public String getTitle(){
    return this.title;
  }
  public String getContent(){
    return this.content;
  }

  public Task(){
    this.idTask = Utils.createId();
    this.title="";
    this.content="";
  }

  public Task(String id, String title,Date creationDate,Date lastModifDate, String content){
    this.idTask = id;
    this.title = title;
    this.creationDate = creationDate;
    this.lastModifDate = lastModifDate;
    this.content = content;
  }

  public String toString(){
    return "ID "+this.idTask+" TITLE "+this.title;
  }
}
