DROP TABLE Tlist IF EXISTS;
CREATE TABLE Tlist(
  id_list varchar(200) primary key,
  title varchar(50),
  description varchar(100)
);

DROP TABLE Ttask IF EXISTS;
CREATE TABLE Ttask(
  id_task varchar(200) primary key,
  title varchar(50),
  crea_date date,
  last_modif_date date,
  id_list varchar(200) references Tlist,
  content varchar(500)
);

--TEST TABLE
DROP TABLE tt IF EXISTS;
CREATE TABLE tt(id int primary key,other int);
INSERT INTO tt values (1,4);
INSERT INTO tt values (2,5);
INSERT INTO tt values (3,6);

COMMIT;
