package main;

import freemarker.template.*;

import org.sql2o.*;
import org.h2.tools.RunScript;
import java.sql.*;

import java.io.*;
import java.lang.*;
import java.util.logging.*;
import dao.*;
import model.*;

import controller.FrontController;


public class Main {

	private static final Logger LOGGER = Logger.getLogger(FrontController.class.getName());

	private static Configuration freemarkerInit() throws Exception {
		Configuration cfg = new Configuration(Configuration.VERSION_2_3_27);
		cfg.setDirectoryForTemplateLoading(new File(Main.class.getResource("/public").getPath()));
		cfg.setDefaultEncoding("UTF-8");
		cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
		cfg.setLogTemplateExceptions(false);
		cfg.setWrapUncheckedExceptions(true);
		return cfg;
	}
	private static void bddInit(){
		Sql2o sql2o = new Sql2o("jdbc:h2:~/test", "sa", "");
		try(org.sql2o.Connection con = sql2o.open()) {
			java.sql.Connection conn=DriverManager.getConnection("jdbc:h2:~/test","sa","");
			RunScript.execute(conn, new FileReader(FrontController.class.getResource("/InitScript.sql").getPath()));
			conn.close();

			ListManager lm = new ListManager();
			TaskManager tm = new TaskManager();

			String id1 = lm.createList("L1","desc");
			tm.createTask("t1","c1",id1);
			tm.createTask("t8","c1ddd",id1);
			id1 = lm.createList("L2","desc");
			tm.createTask("t2","c122",id1);
			con.close();
		}catch(Exception e){
      LOGGER.log(Level.SEVERE,"Error : {0}",e);
    }
	}

	public static void main(String[] args) throws Exception {
		Configuration cfg = freemarkerInit();
		bddInit();
		FrontController mainController = new FrontController(cfg);
	}
}
