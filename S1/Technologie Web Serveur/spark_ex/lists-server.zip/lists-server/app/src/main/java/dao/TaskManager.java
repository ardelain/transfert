package dao;

import model.*;
import utils.*;

import java.util.List;
import java.util.Date;
import java.util.logging.*;

import java.lang.*;

import org.sql2o.*;

public class TaskManager{
  private static final Logger LOGGER = Logger.getLogger(TaskManager.class.getName());
  private Sql2o sql2o;

  public TaskManager(){
    this.sql2o = new Sql2o("jdbc:h2:~/test", "sa", "");
  }

  List<Task> getTasks(String idList){
    try(Connection con = sql2o.open()){
      List<Task> listT = con.createQuery("SELECT * from Ttask WHERE id_list=:id")
            .addParameter("id",idList)
            .addColumnMapping("ID_TASK", "idTask")
            .addColumnMapping("crea_date", "creationDate")
            .addColumnMapping("last_modif_date", "lastModifDate")
            .throwOnMappingFailure(false)
            .executeAndFetch(Task.class);
      con.close();
      return listT;
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"GETTASKS : {0}",e);
      return null;
    }
  }

  public Task getTask(String idTask){
    try(Connection con = sql2o.open()){
      List<Task> task = con.createQuery("SELECT * from Ttask WHERE id_task=:id")
            .addParameter("id",idTask)
            .addColumnMapping("ID_TASK", "idTask")
            .addColumnMapping("crea_date", "creationDate")
            .addColumnMapping("last_modif_date", "lastModifDate")
            .throwOnMappingFailure(false)
            .executeAndFetch(Task.class);
      con.close();
      if(task == null || task.isEmpty())
        return null;
      return task.remove(0);
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"GETTASKS : {0}",e);
      return null;
    }
  }

  public String createTask(String title, String content,String idList){
    try (Connection con = this.sql2o.beginTransaction()) {
      String id = Utils.createId();
      con.createQuery("INSERT INTO Ttask VALUES (:id,:title,:crea_date,:last_modif_date,:idlist,:content)")
          .addParameter("id",id)
          .addParameter("title", title)
          .addParameter("crea_date",new Date(System.currentTimeMillis()))
          .addParameter("last_modif_date",new Date(System.currentTimeMillis()))
          .addParameter("idlist", idList)
          .addParameter("content", content)
          .executeUpdate();
      con.commit();
      return id;
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"PB CREATE : {0}",e);
      return null;
    }
  }

  public void deleteTask(String idTask){
    try (Connection con = this.sql2o.beginTransaction()) {
      con.createQuery("DELETE FROM Ttask WHERE ID_TASK=:id")
          .addParameter("id",idTask)
          .executeUpdate();
      con.commit();
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"PB DELETE : {0}",e);
    }
  }

  void deleteTasksFromList(String idList){
    try (Connection con = this.sql2o.beginTransaction()) {
      con.createQuery("DELETE FROM Ttask WHERE ID_LIST=:id")
          .addParameter("id",idList)
          .executeUpdate();
      con.commit();
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"PB DELETE : {0}",e);
    }
  }

  public void modifyTask(String idTask,String title, String content) throws Exception{
    Connection con = this.sql2o.beginTransaction();
    Task task = getTask(idTask);
    if(task == null)
      throw new Exception("Task "+idTask+" not found");
    if(title == null)
      title = task.getTitle();
    if(content == null)
      content = task.getContent();

    con.createQuery("UPDATE Ttask SET TITLE=:title,CONTENT=:content,LAST_MODIF_DATE=:last_modif_date"+
                    " WHERE ID_TASK=:id")
        .addParameter("id",idTask)
        .addParameter("title", title)
        .addParameter("last_modif_date",new Date(System.currentTimeMillis()))
        .addParameter("content", content)
        .executeUpdate();
    con.commit();
  }

}
