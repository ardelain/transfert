package utils;

import java.lang.Integer;
import java.util.UUID;

public class Utils {

    public static String createId(){
      return Integer.toHexString(UUID.randomUUID().hashCode());
    }
}
