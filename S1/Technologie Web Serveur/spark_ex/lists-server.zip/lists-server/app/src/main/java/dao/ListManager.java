package dao;

import model.*;
import utils.*;

import java.util.List;
import java.util.logging.*;

import java.lang.*;

import org.sql2o.*;

public class ListManager {
  private static final Logger LOGGER = Logger.getLogger(ListManager.class.getName());
  private Sql2o sql2o;

  public ListManager(){
    this.sql2o = new Sql2o("jdbc:h2:~/test", "sa", "");
  }

  public List<TasksList> getLists(){
    TaskManager tm = new TaskManager();

    try(Connection con = sql2o.open()){
      List<TasksList> lists = con.createQuery("SELECT * from Tlist")
                                  .addColumnMapping("ID_LIST", "idList")
                                  .executeAndFetch(TasksList.class);
      if(lists == null){
        return lists;
      }
      for(TasksList l : lists){
        List<Task> listT = tm.getTasks(l.getIdList());
        if(listT != null){
          for(Task t : listT){
            l.addTask(t);
          }
        }
      }
      con.close();
      return lists;
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"GETLISTS : {0}",e);
      return null;
    }
  }

  public TasksList getList(String idList){
    TaskManager tm = new TaskManager();

    try(Connection con = sql2o.open()){
      List<TasksList> Llist = con.createQuery("SELECT * from Tlist WHERE ID_LIST=:id")
                                  .addParameter("id",idList)
                                  .addColumnMapping("ID_LIST", "idList")
                                  .executeAndFetch(TasksList.class);
      if(Llist == null)
        return null;
      TasksList list = Llist.remove(0);

      List<Task> listT = tm.getTasks(list.getIdList());
      if(listT != null){
        for(Task t : listT){
          list.addTask(t);
        }
      }

      con.close();
      return list;
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"GETLISTS : {0}",e);
      return null;
    }
  }


  public String createList(String title,String description){
    try (Connection con = this.sql2o.beginTransaction()) {
      //String id = AESEncryptionDecryption.encrypt(title,Integer.toString((int)(Math.random() * 1000 + 1)));
      String id = Utils.createId();
      con.createQuery("INSERT INTO Tlist VALUES (:id,:title,:description)")
          .addParameter("id",id)
          .addParameter("title",title)
          .addParameter("description",description)
          .executeUpdate();
      con.commit();
      return id;
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"PB CREATE : {0}",e);
      return null;
    }
  }

  public void deleteList(String idList){
    TaskManager tm = new TaskManager();
    tm.deleteTasksFromList(idList);
    try (Connection con = this.sql2o.beginTransaction()) {
      con.createQuery("DELETE FROM Tlist WHERE ID_LIST=:id")
          .addParameter("id",idList)
          .executeUpdate();
      con.commit();
    }catch(Exception e){
      LOGGER.log(Level.SEVERE,"PB DELETE : {0}",e);
    }
  }

  public void modifyList(String idList,String title,String description) throws Exception{
    Connection con = this.sql2o.beginTransaction();
    TasksList list = getList(idList);
    if(list == null){
      throw new Exception("List "+idList+" not found");
    }
    if(title == null){
      title = list.getTitle();
    }
    if(description == null){
      description = list.getDescription();
    }
    con.createQuery("UPDATE Tlist SET TITLE=:title,DESCRIPTION=:description"+
                " WHERE ID_LIST=:id")
        .addParameter("id",idList)
        .addParameter("title",title)
        .addParameter("description",description)
        .executeUpdate();
    con.commit();
  }

}
