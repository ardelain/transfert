package controller;

import freemarker.template.*;
import spark.*;

import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.path;

//put et delete ne sont pas supportes par les form en html
//import static spark.Spark.put;
//import static spark.Spark.delete;

import java.util.HashMap;
import java.util.List;
import java.util.logging.*;

import java.util.*;
import java.io.*;

import model.*;
import dao.*;

import org.sql2o.*;
import org.h2.tools.RunScript;

import java.sql.*;
import java.util.Map;

public class FrontController {

    private static final Logger LOGGER = Logger.getLogger(FrontController.class.getName());

    public FrontController(Configuration cfgFreeMarker) {
        TaskManager tm = new TaskManager();
        ListManager lm = new ListManager();

        //TEST Affiche La liste des listes + leur task
        get("/hello", (req, res) -> {
            List<TasksList> listT = lm.getLists();
            StringBuilder r = new StringBuilder("Hello World");
            for (TasksList tl : listT) {
                r.append(" TL ").append(tl.getIdList()).append(" ").append(tl.getTitle());
                if (tl.getTasks() != null) {
                    for (Task t : tl.getTasks()) {
                        r.append(" task ").append(t.getIdTask());
                    }
                }
            }
            return r.toString();
        });

        get("/", (req, res) -> {
            Writer s = new StringWriter();
            cfgFreeMarker.getTemplate("index.ftlh").process(null, s);
            return s.toString();
        });

        get("/list/add", (req, res) -> {
            Map test = new HashMap();
            test.put("name", "TOASTY");

            Writer s = new StringWriter();
            cfgFreeMarker.getTemplate("add_list_task.ftlh").process(test, s);
            res.status(200);
            return s.toString();
        });

        post("/list/add", (req, res) -> {
            //Check title et description en fct de ce qui est obligatoire
            String idList = lm.createList(req.queryParams("title"), req.queryParams("description"));
            if (idList == null) {
                res.status(500);
                res.redirect("/");
                return "";
            }
            res.redirect("/list/" + idList);
            return "";
        });

        //L'ordre a de l'importance, si /list/:id avant /list/add
        //Quand on appelle /list/add il prend :id=add
        get("/list/:id", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            Map test = new HashMap();
            test.put("name", "TOASTY " + idList);
            test.put("task_list", tList);

            if (tList == null) {
                res.status(404);
                res.redirect("/");
                return null;
            }

            Writer s = new StringWriter();
            cfgFreeMarker.getTemplate("list.ftlh").process(test, s);
            res.status(200);
            return s.toString();
        });

        post("/list/delete/:id", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            if (tList == null) {
                res.status(404);
                res.redirect("/");
                return "";
            }
            lm.deleteList(idList);
            res.redirect("/");
            return "";
        });

        get("/list/modify/:id", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            if (tList == null) {
                res.status(404);
                res.redirect("/");
                return "";
            }

            Map test = new HashMap();
            test.put("name", "TOASTY " + idList);
            test.put("task_list", tList);

            Writer s = new StringWriter();
            cfgFreeMarker.getTemplate("modify_list_task.ftlh").process(test, s);
            res.status(200);
            return s.toString();
        });

        post("/list/modify/:id", (req, res) -> {
            String idList = req.params("id");
            try {
                lm.modifyList(idList, req.queryParams("title"), req.queryParams("description"));
                res.redirect("/list/" + idList);
                return "";
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "PB MODIFY LIST : {0}", e);
                res.status(404);
                res.redirect("/");
                return "";
            }
        });

      /*
      post("/list/:id/tasks/update", (req,res) -> {
        if(req.queryParams().contains("modify")){
          res.header("tasks",req.queryParams("tasks"));
          res.redirect("/list/"+req.params("id")+"/tasks/modify");
          return "";
        }else{
          if(req.queryParams().contains("delete")){
            res.redirect("/list/"+req.params("id")+"/tasks/delete");
            return "";
          }else{
            res.status(404);
            res.redirect("/");
            return "";
          }
        }
      });*/

        post("/list/:id/tasks/delete", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            if (tList == null || !req.queryParams().contains("id_task")) {
                res.status(404);
                res.redirect("/");
                return "";
            }

            tm.deleteTask(req.queryParams("id_task"));
            res.redirect("/list/" + idList);
            return "";
        });

        get("/list/:id/tasks/modify", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);
            Task task = tm.getTask(req.queryParams("id_task"));

            if (tList == null || task == null) {
                res.status(404);
                res.redirect("/");
                return "";
            }

            Map test = new HashMap();
            test.put("name", "TOASTY " + idList);
            test.put("task", task);
            test.put("id_list", idList);

            Writer s = new StringWriter();
            cfgFreeMarker.getTemplate("modify_list_task.ftlh").process(test, s);
            res.status(200);
            return s.toString();
        });

        post("/list/:id/tasks/modify", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            if (tList == null || !req.queryParams().contains("id_task")) {
                res.status(404);
                res.redirect("/");
                return "";
            }
            try {
                tm.modifyTask(req.queryParams("id_task"), req.queryParams("title"), req.queryParams("content"));
                res.redirect("/list/" + idList);
                return "";
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "PB MODIFY TASK : {0}", e);
                res.status(404);
                res.redirect("/");
                return "";
            }
        });

        get("/list/:id/tasks/add", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            if (tList == null) {
                res.status(404);
                res.redirect("/");
                return "";
            }
            Map test = new HashMap();
            test.put("name", "TOASTY");
            test.put("id_list", idList);

            Writer s = new StringWriter();
            cfgFreeMarker.getTemplate("add_list_task.ftlh").process(test, s);
            res.status(200);
            return s.toString();
        });

        post("/list/:id/tasks/add", (req, res) -> {
            String idList = req.params("id");
            TasksList tList = lm.getList(idList);

            if (tList == null) {
                res.status(404);
                res.redirect("/");
                return "";
            }
            //Check title et description en fct de ce qui est obligatoire
            String idTask = tm.createTask(req.queryParams("title"), req.queryParams("content"), idList);
            if (idTask == null) {
                res.status(500);
                res.redirect("/");
                return "";
            }
            res.redirect("/list/" + idList);
            return "";
        });
    }

}
