package model;

public class Test{
  public int id;
  public int other;
  public String lala;

  public Test(){
    this(0,0,"");
  }

  public Test(int id,int other){
    this(id,other,"");
  }

  public Test(int id,int other,String lala){ //land ?
      this.id = id;
      this.other = other;
      this.lala=lala;
  }
}
