package model;
import java.util.*;

import java.io.*;

import utils.*;

public class TasksList {
  private String idList;
  private String title;
  private String description;
  private List<Task> tasks;

  public String getIdList(){
    return this.idList;
  }
  public String getTitle(){
    return this.title;
  }
  public List<Task> getTasks(){
    return this.tasks;
  }
  public String getDescription(){
    return this.description;
  }

  public TasksList(){
    this.idList = Utils.createId();
    this.title = "";
    this.tasks = new ArrayList<>();
    this.description="";
  }

  public TasksList(String id, String title){
    this(id,title,"",new ArrayList<>());
  }

  public TasksList(String id, String title,String description,List<Task> tasks){
    this.idList = id;
    this.title = title;
    this.tasks = tasks;
    this.description = description;
  }

  public void addTask(Task t){
    if(this.tasks == null){
      this.tasks = new ArrayList<>();
    }
    this.tasks.add(t);
  }
}
