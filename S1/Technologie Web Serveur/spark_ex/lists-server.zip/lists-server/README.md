# Lists server  

This application runs with Docker, hence the following instructions.
---

### With this app you can  

* Create lists
* [...]

---
```
.
├── app
│   └── src
│       ├── main
│       │   ├── java
│       │   │   ├── controller
│       │   │   ├── dao
│       │   │   │   ├── ListManager.java
│       │   │   │   └── TaskManager.java
│       │   │   ├── main
│       │   │   │   └── Main.java
│       │   │   ├── model
│       │   │   │   ├── Task.java
│       │   │   │   ├── TasksList.java
│       │   │   │   └── Test.java
│       │   │   └── utils
│       │   │       └── Utils.java
│       │   └── resources
│       │       ├── InitScript.sql
│       │       └── public
│       │           ├── error.html
│       │           ├── index.html
│       │           └── list.ftlh
│       └── test
│           └── java
├── container_startup.sh
├── Dockerfile
├── lib
└── README.md
```

* This spark application is running on *localhost:\<host port\>*.  

* The *Dockerfile* describes this image

* The *src* directory contains this app java files : Main

* The *lib* directory contains all .jar needed to run the app

* The *InitScript.sql* file initializes the database  

* The application runs via __javac__, in the *container_startup.sh* file.

All logs are written directly into the container, you can see them while the container is running thanks to the option *-ti* of the *docker run* command.   

---

### To build and run the container :   
#### Prerequisites   
The base image for this dockerized application is __ubuntu:latest__. In order to have it, this execution is needed :  
```
docker pull ubuntu:latest
```
(We should work with alpine:latest, because it's lighter, but it's not working for the moment I don't know why fuck it)

#### In main directory (with Dockerfile)   

```
docker build --rm -t server .
```

#### Run the app   
```
docker run --rm -p <host port>:4567 -ti server
```

##### Notes  

To remove 'None' tagged images :
```
docker rmi -f $(docker images --filter “dangling=true” -q --no-trunc)
```
