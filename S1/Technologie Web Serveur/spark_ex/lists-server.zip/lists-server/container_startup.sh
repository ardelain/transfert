#!/bin/bash
javac -cp 'lib/*:.' -d bin -sourcepath src/main/java src/main/java/main/Main.java
java -cp '.:bin:lib/*' main/Main
