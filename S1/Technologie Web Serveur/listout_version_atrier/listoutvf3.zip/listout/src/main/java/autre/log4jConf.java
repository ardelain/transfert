package autre;

import org.apache.log4j.Logger;

public class log4jConf {
    public static Logger log = Logger.getLogger(log4jConf.class);
}
