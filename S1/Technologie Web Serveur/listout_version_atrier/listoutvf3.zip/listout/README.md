# listout
"Tout pour faire des Listes."
site de liste en java (11) / spark / freemarker / h2 / sql2o sur intelliJ IDEA

</br>
<img src="/src/main/ressources/image/todoliste.png" alt="My cool logo"/>
</br>

(mais pas fini)

Licence publique générale GNU (GPL3)
