package model.test;

import java.util.Date;

public class UnElement extends AListe{
}
