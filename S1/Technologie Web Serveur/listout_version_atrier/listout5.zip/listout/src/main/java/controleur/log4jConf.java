package controleur;

import org.apache.log4j.Logger;

public class log4jConf {
    static Logger log = Logger.getLogger(log4jConf.class);
}
