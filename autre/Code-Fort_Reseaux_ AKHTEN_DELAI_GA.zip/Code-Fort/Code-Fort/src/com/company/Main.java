package com.company;

//Fatima-Ezzohra AKHTEN et Arthur DELAIN
public class Main {

    public static void main(String[] args) {
        System.out.println("QR CODE JAVA TEST :");

        //pour indiquer le message, lancemement pop up
        TestText test = new TestText();

    }
}
