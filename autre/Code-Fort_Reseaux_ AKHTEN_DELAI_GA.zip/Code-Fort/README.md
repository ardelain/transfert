# Code-Fort
Protocoles de communication graphique 2D\Code barre  bidimensionnel \Codes matriciels en Java (intel ij)
</br>
(doc en Latex avec TexMaker)
</br>
![QrCode.pdf](https://github.com/ardelain/Code-Fort/blob/master/ressources/QrCode.pdf)
</br>
